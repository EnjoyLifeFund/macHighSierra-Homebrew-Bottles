#include <stdio.h>

void f2()
{
	printf("hello\n");
}
