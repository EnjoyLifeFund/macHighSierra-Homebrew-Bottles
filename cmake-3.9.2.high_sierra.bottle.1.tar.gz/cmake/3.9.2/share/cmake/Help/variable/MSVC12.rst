MSVC12
------

Discouraged.  Use the :variable:`MSVC_VERSION` variable instead.

``True`` when using the Microsoft Visual Studio ``v120`` toolset
(``cl`` version 18) or another compiler that simulates it.
