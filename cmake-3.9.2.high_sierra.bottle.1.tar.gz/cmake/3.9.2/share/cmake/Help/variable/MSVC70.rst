MSVC70
------

Discouraged.  Use the :variable:`MSVC_VERSION` variable instead.

``True`` when using Microsoft Visual C++ 7.0.

Set to ``true`` when the compiler is version 7.0 of Microsoft Visual C++.
