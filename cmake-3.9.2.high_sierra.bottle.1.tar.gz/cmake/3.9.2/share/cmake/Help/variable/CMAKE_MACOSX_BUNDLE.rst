CMAKE_MACOSX_BUNDLE
-------------------

Default value for :prop_tgt:`MACOSX_BUNDLE` of targets.

This variable is used to initialize the :prop_tgt:`MACOSX_BUNDLE` property on
all the targets.  See that target property for additional information.
