CMAKE_Fortran_MODULE_DIRECTORY
------------------------------

Fortran module output directory.

This variable is used to initialize the :prop_tgt:`Fortran_MODULE_DIRECTORY`
property on all the targets.  See that target property for additional
information.
