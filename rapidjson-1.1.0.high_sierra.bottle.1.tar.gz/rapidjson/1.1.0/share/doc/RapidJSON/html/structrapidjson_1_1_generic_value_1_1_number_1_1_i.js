var structrapidjson_1_1_generic_value_1_1_number_1_1_i =
[
    [ "i", "structrapidjson_1_1_generic_value_1_1_number_1_1_i.html#aee43f62c5529fb886642fb410ff93a05", null ],
    [ "padding", "structrapidjson_1_1_generic_value_1_1_number_1_1_i.html#ae0b11ea3695bf3abb23d5cef1f1517d2", null ]
];