var error_8h =
[
    [ "RAPIDJSON_ERROR_CHARTYPE", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga7e4636fd48d0148f102b8a13f0539d8c", null ],
    [ "RAPIDJSON_ERROR_STRING", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gabe2e1bd1349e5a7d6c1af78c05a98f0d", null ],
    [ "GetParseErrorFunc", "error_8h.html#gac1bee7fdafeba5a85c27943fcde12882", null ],
    [ "ParseErrorCode", "error_8h.html#ga7d3acf640886b1f2552dc8c4cd6dea60", [
      [ "kParseErrorNone", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a86a60b723dca32df5debab2c3db4235f", null ],
      [ "kParseErrorDocumentEmpty", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a06183076357ebd9eca228666f614c286", null ],
      [ "kParseErrorDocumentRootNotSingular", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a2022599bcd4f64d58885a026f95751d5", null ],
      [ "kParseErrorValueInvalid", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab7fa69bce0c393cf3a2b6065111f2f57", null ],
      [ "kParseErrorObjectMissName", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab707b848425668e765def25554735242", null ],
      [ "kParseErrorObjectMissColon", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a58e952084a0dfdbc5630f624252aef5c", null ],
      [ "kParseErrorObjectMissCommaOrCurlyBracket", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a2a81a684f39fc882ec99f07e86343f73", null ],
      [ "kParseErrorArrayMissCommaOrSquareBracket", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a1a4ac97731f997e9591b40f98ecd9f93", null ],
      [ "kParseErrorStringUnicodeEscapeInvalidHex", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a23c38bf88b8448555c0eb41e1735bd92", null ],
      [ "kParseErrorStringUnicodeSurrogateInvalid", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a636209a2e516fbdb4db5ad0a83a6b386", null ],
      [ "kParseErrorStringEscapeInvalid", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a8dd0af5e6103a6503c61c38cb2b0bab9", null ],
      [ "kParseErrorStringMissQuotationMark", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60af7daa91caa53abb881ea231a874a4f40", null ],
      [ "kParseErrorStringInvalidEncoding", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a62ce0f5c74e4ab34ac325d2adda8fa8f", null ],
      [ "kParseErrorNumberTooBig", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a240cebadea89f7282ab263b5a22c9805", null ],
      [ "kParseErrorNumberMissFraction", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60ac840ece3ba6874fe6f16c01ebb71031f", null ],
      [ "kParseErrorNumberMissExponent", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a28a1c720ae63560780ccd992dc999ab7", null ],
      [ "kParseErrorTermination", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab250f87c3d8454c579364b5a0f697a50", null ],
      [ "kParseErrorUnspecificSyntaxError", "error_8h.html#gga7d3acf640886b1f2552dc8c4cd6dea60a7abf1a337294d984a3f4d18b5843fb24", null ]
    ] ]
];