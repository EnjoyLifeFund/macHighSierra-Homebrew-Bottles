var group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g =
[
    [ "RAPIDJSON_48BITPOINTER_OPTIMIZATION", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga93fb983f78208d12c822376e1ea6d185", null ],
    [ "RAPIDJSON_ALIGN", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga583915242504c7fdb36e826f02f76242", null ],
    [ "RAPIDJSON_ASSERT", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#gabeba18d612187bad2ac62aed9276d47c", null ],
    [ "RAPIDJSON_ENDIAN", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#gaba2445f582142cf918e74c2d22d1aa07", null ],
    [ "RAPIDJSON_HAS_STDSTRING", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga2f2eef0ee4477f3fe5874703a66e997f", null ],
    [ "RAPIDJSON_LIKELY", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga5dc14176a9e71ace282404b0bcda57a1", null ],
    [ "RAPIDJSON_MAJOR_VERSION", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#gaf1ff1685be6cbebb5d4b2ab997776f45", null ],
    [ "RAPIDJSON_MINOR_VERSION", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#gaf9125105c593a636a79f1c2d96835376", null ],
    [ "RAPIDJSON_NAMESPACE", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga743a79d3af927391fe3eb5c979136899", null ],
    [ "RAPIDJSON_NO_INT64DEFINE", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga7f4e50c35dae3b015390daa6d48ce23c", null ],
    [ "RAPIDJSON_NO_SIZETYPEDEFINE", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga250603aa9e2a12429b25ba0c8108ad4f", null ],
    [ "RAPIDJSON_PARSE_DEFAULT_FLAGS", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga77005e892e6601599beaf421b0395c31", null ],
    [ "RAPIDJSON_PATCH_VERSION", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#gaf967d31be43666ce7f53756d73bd1cdf", null ],
    [ "RAPIDJSON_SIMD", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga0ccf72f3ebc4b3306ab669f95ca5c64b", null ],
    [ "RAPIDJSON_UNLIKELY", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga6a2b1695c13e77ae425e3cbac980ccb5", null ],
    [ "RAPIDJSON_VERSION_STRING", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#gad283cfde97d9a32b7d8e8107b11f70a6", null ],
    [ "RAPIDJSON_WRITE_DEFAULT_FLAGS", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html#ga1975595e2f1dc20a2d4859f340ac88c6", null ]
];