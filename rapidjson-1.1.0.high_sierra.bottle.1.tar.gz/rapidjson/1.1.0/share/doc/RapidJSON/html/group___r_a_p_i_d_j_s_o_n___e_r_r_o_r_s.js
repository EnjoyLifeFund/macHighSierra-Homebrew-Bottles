var group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s =
[
    [ "ParseResult", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#structrapidjson_1_1_parse_result", [
      [ "ParseResult", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a0f03679d5fa2736d9e351541e767fac1", null ],
      [ "ParseResult", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ad15710045513f13ba526753c4a2cb59b", null ],
      [ "Clear", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a17c9f7f81675283393222658d613000f", null ],
      [ "Code", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a3c6a1f7b7dc21363a255eb10a3c0e00e", null ],
      [ "IsError", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ab6d87c6ce9c849f35e902fbe23f485c4", null ],
      [ "Offset", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a85036788b0cfd1c676900de6f8260bd6", null ],
      [ "operator bool", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a1a875ffec30790e99225d5828975fd32", null ],
      [ "operator==", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a53e838c5114c4770b01ba5fb4fe2ec09", null ],
      [ "operator==", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a512e065514f0c55c539ef70033a3f508", null ],
      [ "Set", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a40c0bd4d6c535c57acbb5c2e656bea38", null ],
      [ "operator==", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a58c9982e833d1c74686506ac7449200c", null ]
    ] ],
    [ "RAPIDJSON_ERROR_CHARTYPE", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga7e4636fd48d0148f102b8a13f0539d8c", null ],
    [ "RAPIDJSON_ERROR_STRING", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gabe2e1bd1349e5a7d6c1af78c05a98f0d", null ],
    [ "RAPIDJSON_PARSE_ERROR", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gae3689840fa6e89a241313f33b602f865", null ],
    [ "RAPIDJSON_PARSE_ERROR_NORETURN", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga7f8c4265b2edda78568ae3338aaf1461", null ],
    [ "GetParseErrorFunc", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gac1bee7fdafeba5a85c27943fcde12882", null ],
    [ "ParseErrorCode", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga7d3acf640886b1f2552dc8c4cd6dea60", [
      [ "kParseErrorNone", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a86a60b723dca32df5debab2c3db4235f", null ],
      [ "kParseErrorDocumentEmpty", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a06183076357ebd9eca228666f614c286", null ],
      [ "kParseErrorDocumentRootNotSingular", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a2022599bcd4f64d58885a026f95751d5", null ],
      [ "kParseErrorValueInvalid", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab7fa69bce0c393cf3a2b6065111f2f57", null ],
      [ "kParseErrorObjectMissName", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab707b848425668e765def25554735242", null ],
      [ "kParseErrorObjectMissColon", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a58e952084a0dfdbc5630f624252aef5c", null ],
      [ "kParseErrorObjectMissCommaOrCurlyBracket", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a2a81a684f39fc882ec99f07e86343f73", null ],
      [ "kParseErrorArrayMissCommaOrSquareBracket", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a1a4ac97731f997e9591b40f98ecd9f93", null ],
      [ "kParseErrorStringUnicodeEscapeInvalidHex", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a23c38bf88b8448555c0eb41e1735bd92", null ],
      [ "kParseErrorStringUnicodeSurrogateInvalid", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a636209a2e516fbdb4db5ad0a83a6b386", null ],
      [ "kParseErrorStringEscapeInvalid", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a8dd0af5e6103a6503c61c38cb2b0bab9", null ],
      [ "kParseErrorStringMissQuotationMark", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60af7daa91caa53abb881ea231a874a4f40", null ],
      [ "kParseErrorStringInvalidEncoding", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a62ce0f5c74e4ab34ac325d2adda8fa8f", null ],
      [ "kParseErrorNumberTooBig", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a240cebadea89f7282ab263b5a22c9805", null ],
      [ "kParseErrorNumberMissFraction", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ac840ece3ba6874fe6f16c01ebb71031f", null ],
      [ "kParseErrorNumberMissExponent", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a28a1c720ae63560780ccd992dc999ab7", null ],
      [ "kParseErrorTermination", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab250f87c3d8454c579364b5a0f697a50", null ],
      [ "kParseErrorUnspecificSyntaxError", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a7abf1a337294d984a3f4d18b5843fb24", null ]
    ] ],
    [ "PointerParseErrorCode", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gade540ee4cc2a416c23b8ee2c12393c7b", [
      [ "kPointerParseErrorNone", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba9094f236b2ec70c42f1ea91dffc1e39b", null ],
      [ "kPointerParseErrorTokenMustBeginWithSolidus", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba2f2f8b238e201b7d540e8914bbfd2bed", null ],
      [ "kPointerParseErrorInvalidEscape", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba907c9fe4e541b257513e3a18635379f7", null ],
      [ "kPointerParseErrorInvalidPercentEncoding", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba29831a02b8ee23a05d552b47f4d64d28", null ],
      [ "kPointerParseErrorCharacterMustPercentEncode", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7bae244a98f53279fda5a750f847b81c54f", null ]
    ] ],
    [ "GetParseError_En", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gabdaf1a7a4db30fb0e3d927fdf0fabe79", null ]
];