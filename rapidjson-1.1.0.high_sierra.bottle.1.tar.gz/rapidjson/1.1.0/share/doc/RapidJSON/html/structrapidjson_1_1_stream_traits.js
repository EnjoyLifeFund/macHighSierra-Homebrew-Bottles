var structrapidjson_1_1_stream_traits =
[
    [ "copyOptimization", "structrapidjson_1_1_stream_traits.html#a3a11abaf56440885401e34830a819c53af6f7f81d1e208f1041e618b57e0d3828", null ]
];