var structrapidjson_1_1_generic_member =
[
    [ "name", "structrapidjson_1_1_generic_member.html#ae820eaa74b415a9073f3f3855f6c6607", null ],
    [ "value", "structrapidjson_1_1_generic_member.html#a8ffff2076e62d988a070a136da6ffca6", null ]
];