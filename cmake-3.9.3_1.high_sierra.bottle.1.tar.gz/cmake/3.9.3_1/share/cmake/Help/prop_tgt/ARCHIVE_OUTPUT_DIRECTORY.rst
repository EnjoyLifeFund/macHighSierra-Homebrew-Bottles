ARCHIVE_OUTPUT_DIRECTORY
------------------------

.. |XXX| replace:: :ref:`ARCHIVE <Archive Output Artifacts>`
.. |xxx| replace:: archive
.. |CMAKE_XXX_OUTPUT_DIRECTORY| replace:: CMAKE_ARCHIVE_OUTPUT_DIRECTORY
.. include:: XXX_OUTPUT_DIRECTORY.txt

See also the :prop_tgt:`ARCHIVE_OUTPUT_DIRECTORY_<CONFIG>` target property.
