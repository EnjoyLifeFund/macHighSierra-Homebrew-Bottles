HAS_CXX
-------

Link the target using the C++ linker tool (obsolete).

This is equivalent to setting the LINKER_LANGUAGE property to CXX.
See that property's documentation for details.
