.. Boost.Python NumPy extension documentation master file, created by
   sphinx-quickstart on Thu Oct 27 09:04:58 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the documentation of the Boost.Python NumPy extension!
=================================================================

.. toctree::
   :maxdepth: 2

   Tutorial <tutorial/index>
   Reference <reference/index>

