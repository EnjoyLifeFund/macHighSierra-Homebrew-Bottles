**To delete a model in the given API**

Command::

  aws apigateway delete-model --rest-api-id 1234123412 --model-name 'customModel'
