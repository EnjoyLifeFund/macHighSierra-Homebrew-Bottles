class Cputhrottle < Formula
  desc "Limit the CPU usage of a process"
  homepage "http://www.willnolan.com/cputhrottle/cputhrottle.html"
  url "http://www.willnolan.com/cputhrottle/cputhrottle-1.0.0.tar.gz"
  sha256 "08243656d0abf6dd5fd9542d33553507ce395ee4e0a1aeb5df08ca78bc83ec21"
  version_scheme 1

  def install
    system "make", "all"
    bin.install "cputhrottle"
  end

  test do
    # Needs root for proper functionality test.
    output = pipe_output("#{bin}/cputhrottle 2>&1")
    assert_match "Please supply PID to throttle", output
  end
end
