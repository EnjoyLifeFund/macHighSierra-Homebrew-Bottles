APPLE
-----

``True`` if running on OS X.

Set to ``true`` on OS X.
