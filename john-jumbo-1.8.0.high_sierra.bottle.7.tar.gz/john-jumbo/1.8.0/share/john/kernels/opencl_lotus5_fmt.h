#ifndef _LOTUS5_H
#define _LOTUS5_H

#define PLAINTEXT_LENGTH               16
#define BINARY_SIZE                    16
#define KEY_SIZE_IN_ARCH_WORD_32       ((PLAINTEXT_LENGTH >> 2) + 1)
#define BINARY_SIZE_IN_ARCH_WORD_32    (BINARY_SIZE >> 2)

#endif
