rocks_trees = {
   { name = [[user]], root = home..[[/.luarocks]] },
   { name = [[system]], root = [[@@HOMEBREW_PREFIX@@]] }
}
