VS_SCC_AUXPATH
--------------

Visual Studio Source Code Control Aux Path.

Can be set to change the visual studio source code control auxpath
property.
