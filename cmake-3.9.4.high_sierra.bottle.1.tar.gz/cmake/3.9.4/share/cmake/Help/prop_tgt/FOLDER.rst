FOLDER
------

Set the folder name. Use to organize targets in an IDE.

Targets with no FOLDER property will appear as top level entities in
IDEs like Visual Studio.  Targets with the same FOLDER property value
will appear next to each other in a folder of that name.  To nest
folders, use FOLDER values such as 'GUI/Dialogs' with '/' characters
separating folder levels.
