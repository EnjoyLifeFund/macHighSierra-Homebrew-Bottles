ENABLED_LANGUAGES
-----------------

Read-only property that contains the list of currently enabled languages

Set to list of currently enabled languages.
