#!/bin/sh
# Vendorize pep 425 tagging scheme
cp ../pep425/pep425tags.py wheel
