/* ompi/mpiext/cuda/c/mpiext_cuda_c.h.  Generated from mpiext_cuda_c.h.in by configure.  */
/*
 * Copyright (c) 2004-2009 The Trustees of Indiana University.
 *                         All rights reserved.
 * Copyright (c) 2010-2012 Cisco Systems, Inc.  All rights reserved.
 * Copyright (c) 2010      Oracle and/or its affiliates.  All rights reserved.
 * Copyright (c) 2015      NVIDIA, Inc. All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 *
 */

#define MPIX_CUDA_AWARE_SUPPORT 0
OMPI_DECLSPEC int MPIX_Query_cuda_support(void);
