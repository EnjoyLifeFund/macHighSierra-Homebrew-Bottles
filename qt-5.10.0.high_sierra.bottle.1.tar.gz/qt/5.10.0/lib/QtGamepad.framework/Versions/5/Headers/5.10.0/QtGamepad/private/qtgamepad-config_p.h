#define QT_FEATURE_sdl2 1
