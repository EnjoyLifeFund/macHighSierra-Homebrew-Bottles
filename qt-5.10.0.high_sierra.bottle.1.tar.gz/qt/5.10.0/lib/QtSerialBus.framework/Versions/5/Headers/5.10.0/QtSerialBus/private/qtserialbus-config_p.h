#define QT_FEATURE_socketcan -1
#define QT_FEATURE_socketcan_fd -1
