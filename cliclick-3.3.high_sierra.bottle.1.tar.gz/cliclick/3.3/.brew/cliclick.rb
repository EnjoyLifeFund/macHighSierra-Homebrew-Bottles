class Cliclick < Formula
  desc "Tool for emulating mouse and keyboard events"
  homepage "https://www.bluem.net/jump/cliclick/"
  url "https://github.com/BlueM/cliclick/archive/3.3.tar.gz"
  sha256 "e434a951f0ab0c44ee965058f382cb22ec2b9027acdd17679e1244af3117965a"
  head "https://github.com/BlueM/cliclick.git"

  def install
    system "make"
    bin.install "cliclick"
  end

  test do
    system bin/"cliclick", "p:OK"
  end
end
