//---------------------------------------------------------------------------
//	Greenplum Database
//	Copyright (C) 2015 Pivotal Software, Inc.
//
//	@filename:
//		version.h
//
//	@doc:
//		GPORCA version number
//
//---------------------------------------------------------------------------
#ifndef GPORCA_version_H
#define GPORCA_version_H

#define GPORCA_VERSION_STRING "2.42.0"

#endif  // GPORCA_version_H
// EOF
